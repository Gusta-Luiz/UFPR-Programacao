#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>  /* Biblioteca de fontes */
#include <allegro5/allegro_image.h> /* Biblioteca de imagens */
#include <allegro5/allegro_ttf.h>   /* Biblioteca de fontes TrueType */

#include "Global.h"                 /* Biblioteca de funcoes globais, iniciadas por GL_ */
#include "Gamelib.h"                /* Biblioteca de funcoes do jogo, iniciadas por GGL_ */

/* Cria*/